#!/usr/bin/env python
import inkex
import logging
import os
import tempfile
import urllib.request
import socket
import urllib.parse
from lxml import etree

# Setup logging
log_dir = os.path.join(tempfile.gettempdir(), 'svg_nesting_logs')
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, 'svg_nesting.log')
logging.basicConfig(filename=log_file, level=logging.DEBUG)
logger = logging.getLogger(__name__)

class SVGNesting(inkex.EffectExtension):
    def __init__(self):
        super().__init__()
        self.arg_parser.add_argument("--server_ip", type=str, default="127.0.0.1")
        self.arg_parser.add_argument("--server_port", type=int, default=3000)

    def send_request(self, method, path, fields=None, files=None):
        """Send an HTTP request using sockets for maximum reliability and to bypass proxies."""
        # Clean up server IP and port
        host = self.options.server_ip.strip()
        if host.startswith("http://"): host = host[7:]
        if host.startswith("https://"): host = host[8:]
        if "/" in host: host = host.split("/")[0]
        if ":" in host:
            host, port_str = host.split(":")
            try:
                port = int(port_str)
            except:
                port = self.options.server_port
        else:
            port = self.options.server_port

        boundary = '----Boundary' + os.urandom(16).hex()
        body = bytearray()

        if method == "POST":
            content_type = f'multipart/form-data; boundary={boundary}'
            # Add regular fields
            if fields:
                for name, value in fields.items():
                    body.extend(f'--{boundary}\r\n'.encode('utf-8'))
                    body.extend(f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode('utf-8'))
                    body.extend(f'{value}\r\n'.encode('utf-8'))

            # Add files
            if files:
                for field_name, file_info in files.items():
                    filename, data, f_content_type = file_info
                    if isinstance(data, str):
                        data = data.encode('utf-8')
                    body.extend(f'--{boundary}\r\n'.encode('utf-8'))
                    body.extend(f'Content-Disposition: form-data; name="{field_name}"; filename="{filename}"\r\n'.encode('utf-8'))
                    body.extend(f'Content-Type: {f_content_type}\r\n\r\n'.encode('utf-8'))
                    body.extend(data)
                    body.extend(b'\r\n')

            body.extend(f'--{boundary}--\r\n'.encode('utf-8'))
        else:
            content_type = 'application/x-www-form-urlencoded'

        # Create request headers
        headers = [
            f'{method} {path} HTTP/1.1',
            f'Host: {host}:{port}',
            f'Content-Type: {content_type}',
            f'Content-Length: {len(body)}',
            'Connection: close',
            '',
            ''
        ]
        request_head = '\r\n'.join(headers).encode('utf-8')

        # Send request
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(30)
        try:
            sock.connect((host, port))
            sock.sendall(request_head + body)

            # Receive response
            response_data = bytearray()
            while True:
                chunk = sock.recv(8192)
                if not chunk: break
                response_data.extend(chunk)

            # Parse response
            response_text = response_data.decode('utf-8', errors='ignore')
            if '\r\n\r\n' not in response_text:
                raise Exception("Invalid server response")
                
            resp_headers, resp_body = response_text.split('\r\n\r\n', 1)
            status_line = resp_headers.split('\r\n')[0]
            status_code = int(status_line.split()[1])

            return status_code, resp_body
        finally:
            sock.close()

    def effect(self):
        # Get selected elements
        selected = self.svg.selected
        modeupload = bool(selected)

        try:
            if modeupload:
                # Create a temporary SVG with selected elements
                svg_data = self.create_svg_from_selection(selected)
                fields = {'inkscape': 'y'}
                files = {
                    'svg_data': ('input.svg', svg_data, 'image/svg+xml')
                }
                status_code, response_text = self.send_request("POST", "/upload_svg", fields, files)
                if status_code == 200:
                    inkex.errormsg("Selection uploaded successfully to Nesting App.")
                else:
                    inkex.errormsg(f"Failed to upload. Status code: {status_code}")
            else:                
                # Use GET method to get solution SVG from server
                status_code, svg_content = self.send_request("GET", "/result_svg")
                if status_code == 200:
                    try:
                        # Clean up SVG content: find the first '<' to skip any HTTP junk like chunk sizes
                        start_idx = svg_content.find('<')
                        if start_idx != -1:
                            svg_content = svg_content[start_idx:]
                        
                        # Clean up XML
                        nested_svg = etree.fromstring(svg_content.strip().encode('utf-8'))
                        self.import_nested_svg(nested_svg)
                    except Exception as e:
                        logger.exception("Parser error")
                        inkex.errormsg(f"Error parsing SVG response: {str(e)}\nContent was: {svg_content[:100]}...")
                elif status_code == 404:
                    inkex.errormsg("No solution SVG found on server. Please run nesting and click 'Select as Best' first.")
                else:
                    inkex.errormsg(f"Failed to retrieve solution. Status code: {status_code}")
                
        except socket.timeout:
            inkex.errormsg(f"Connection timeout to server at {self.options.server_ip}:{self.options.server_port}")
        except socket.error as e:
            inkex.errormsg(f"Network error (Check if NestJS app is running): {str(e)}")
        except Exception as e:
            logger.exception("Error in process")
            inkex.errormsg(f"Error: {str(e)}")

    def create_svg_from_selection(self, selected):
        """Create a new SVG document containing only the selected elements."""
        # Create a new SVG document
        svg = etree.Element("svg", nsmap=self.svg.nsmap)
        svg.set("xmlns", "http://www.w3.org/2000/svg")
        
        # Add selected elements to the new SVG
        for element in selected.values():
            # Convert to path if it's not already a path
            if element.tag.endswith('}path') or element.tag == 'path':
                # Clone the path element
                clone = etree.fromstring(etree.tostring(element))
            else:
                # Convert shape to path
                clone = self.shape_to_path(element)
            
            # Get the bounding box
            bbox = element.bounding_box()
            if bbox:
                # Ensure the element has a transform attribute
                transform = element.get('transform', '')
                # Add translation to keep position relative to original
                if transform:
                    clone.set('transform', transform)
            
            svg.append(clone)
        
        # Convert to string
        return etree.tostring(svg, encoding='unicode', method='xml')
    
    def shape_to_path(self, element):
        """Convert various SVG shapes to path elements."""
        tag = element.tag.split('}')[-1] if '}' in element.tag else element.tag
        path = etree.Element('path')
        
        # Copy common attributes (id, style, fill, stroke, etc.)
        for attr in ['id', 'style', 'fill', 'stroke', 'stroke-width', 'transform']:
            if element.get(attr):
                path.set(attr, element.get(attr))
        
        if tag == 'rect':
            # Convert rectangle to path
            x = float(element.get('x', 0))
            y = float(element.get('y', 0))
            width = float(element.get('width', 0))
            height = float(element.get('height', 0))
            rx = float(element.get('rx', 0))
            ry = float(element.get('ry', rx))
            
            if rx > 0 or ry > 0:
                # Rounded rectangle
                rx = min(rx, width / 2)
                ry = min(ry, height / 2)
                d = f'M {x + rx},{y} L {x + width - rx},{y} Q {x + width},{y} {x + width},{y + ry} L {x + width},{y + height - ry} Q {x + width},{y + height} {x + width - rx},{y + height} L {x + rx},{y + height} Q {x},{y + height} {x},{y + height - ry} L {x},{y + ry} Q {x},{y} {x + rx},{y} Z'
            else:
                # Regular rectangle
                d = f'M {x},{y} L {x + width},{y} L {x + width},{y + height} L {x},{y + height} Z'
            path.set('d', d)
        
        elif tag == 'circle':
            # Convert circle to path
            cx = float(element.get('cx', 0))
            cy = float(element.get('cy', 0))
            r = float(element.get('r', 0))
            d = f'M {cx - r},{cy} A {r},{r} 0 1,0 {cx + r},{cy} A {r},{r} 0 1,0 {cx - r},{cy} Z'
            path.set('d', d)
        
        elif tag == 'ellipse':
            # Convert ellipse to path
            cx = float(element.get('cx', 0))
            cy = float(element.get('cy', 0))
            rx = float(element.get('rx', 0))
            ry = float(element.get('ry', 0))
            d = f'M {cx - rx},{cy} A {rx},{ry} 0 1,0 {cx + rx},{cy} A {rx},{ry} 0 1,0 {cx - rx},{cy} Z'
            path.set('d', d)
        
        elif tag == 'line':
            # Convert line to path
            x1 = float(element.get('x1', 0))
            y1 = float(element.get('y1', 0))
            x2 = float(element.get('x2', 0))
            y2 = float(element.get('y2', 0))
            d = f'M {x1},{y1} L {x2},{y2}'
            path.set('d', d)
        
        elif tag == 'polyline':
            # Convert polyline to path
            points = element.get('points', '')
            if points:
                point_list = points.replace(',', ' ').split()
                d = f'M {point_list[0]},{point_list[1]}'
                for i in range(2, len(point_list), 2):
                    d += f' L {point_list[i]},{point_list[i+1]}'
                path.set('d', d)
        
        elif tag == 'polygon':
            # Convert polygon to path
            points = element.get('points', '')
            if points:
                point_list = points.replace(',', ' ').split()
                d = f'M {point_list[0]},{point_list[1]}'
                for i in range(2, len(point_list), 2):
                    d += f' L {point_list[i]},{point_list[i+1]}'
                d += ' Z'  # Close the path
                path.set('d', d)
        
        elif tag == 'path':
            # Already a path, just return a clone
            return etree.fromstring(etree.tostring(element))
        
        else:
            # For unknown shapes, try to use Inkscape's convert_to_path if available
            logger.warning(f"Unknown shape type: {tag}, attempting direct clone")
            return etree.fromstring(etree.tostring(element))
        
        return path
    def import_nested_svg(self, nested_svg):
        """Import the nested SVG content into the current document."""
        # Get the current layer or create a new one
        layer = self.svg.get_current_layer()

        # Create a group for the nested paths
        group = etree.SubElement(layer, 'g')
        group.set(inkex.addNS('label', 'inkscape'), 'Nested Parts')

        # Import each path from the nested SVG
        for element in nested_svg:
            if element.tag.endswith('}path') or element.tag == 'path':
                # Create a new path element
                path = etree.SubElement(group, 'path')

                # Copy attributes
                for attr, value in element.items():
                    path.set(attr, value)

if __name__ == '__main__':
    SVGNesting().run()
